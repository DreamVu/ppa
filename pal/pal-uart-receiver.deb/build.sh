g++ uart_receiver.cpp -o receiver -O3

