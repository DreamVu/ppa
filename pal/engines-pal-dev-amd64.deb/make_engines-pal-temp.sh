if ! command -v trtexec &> /dev/null
then
    FILE=/usr/src/tensorrt/bin/trtexec
    if test -f "$FILE"; then
        export PATH=$PATH:/usr/src/tensorrt/bin
    else
        echo "Requirements not complete. Installing..."
        FOLDER=/usr/src/tensorrt/samples/trtexec/
        if [ -d "$FOLDER" ]; then
            sudo chown -R $USER: /usr/src/tensorrt/
            cd /usr/src/tensorrt/samples/trtexec/
            make
            cd -
            if test -f "$FILE"; then
                export PATH=$PATH:/usr/src/tensorrt/bin
            else
                echo "Can't locate trtexec. run: 'sudo find / -name trtexec' and add it to the PATH"
                exit
            fi
        else
            echo "Can't locate trtexec folder. run: 'sudo find / -name tensorrt' and find the folder with trtexec. Go in that folder and run 'make'"
            exit
        fi
    fi
fi

success=""
failed=""


LOW_RAM_SYSTEM=0
# Get the total RAM in kilobytes
total_ram=$(awk '/MemTotal/ {print $2}' /proc/meminfo)

# Convert the total RAM from kilobytes to gigabytes
total_ram_gb=$(echo "scale=2; $total_ram / 1024 / 1024" | bc)

# Check if the total RAM is less than 7.5GB
if (( $(echo "$total_ram_gb < 7.5" | bc -l) )); then
  LOW_RAM_SYSTEM=1
fi


#engine_depth384_1120_pal
b=engine_depth384_1120_pal
echo "generating engine for $b"

sudo touch /usr/local/bin/data/pal/$b".trt"
sudo chown -R $SUDO_USER:$SUDO_USER  /usr/local/bin/data/pal/$b".trt"

if [ $LOW_RAM_SYSTEM -eq 1 ]; then
    MAX_SHAPE=INPUTS:1x3x384x1120
else
    MAX_SHAPE=INPUTS:2x3x384x1120
fi

trtexec --onnx=/generate/$b".onnx" --int8 --fp16 --calib=/generate/$b".cache" --saveEngine=/usr/local/bin/data/pal/$b".trt" --workspace=$1 --minShapes=INPUTS:1x3x384x1120 --optShapes=INPUTS:1x3x384x1120 --maxShapes=$MAX_SHAPE --shapes=INPUTS:1x3x384x1120

if [ $? -eq 0 ]; then 
    rm /generate/$b".onnx"
    echo "$b engine created"
    success="$success$b "
else
    echo "$b engine creation failed"
    $failed="$failed$b "
fi

#engine_floor224_672_pal_b2(gpu)
b=engine_floor224_672_pal_b2
b_gpu=engine_floor224_672_pal_b2_gpu

if [ $LOW_RAM_SYSTEM -eq 1 ]; then
    rm /generate/$b".onnx"
else
    echo "generating engine for $b_gpu"

    sudo touch /usr/local/bin/data/pal/$b_gpu".trt"
    sudo chown -R $SUDO_USER:$SUDO_USER  /usr/local/bin/data/pal/$b_gpu".trt"

    trtexec --onnx=/generate/$b".onnx" --int8 --fp16 --calib=/generate/$b".cache" --saveEngine=/usr/local/bin/data/pal/$b_gpu".trt" --workspace=$1

    if [ $? -eq 0 ]; then 
        rm /generate/$b".onnx"
        echo "$b_gpu engine created"
        success="$success$b_gpu "
    else
        echo "$b_gpu engine creation failed"
        $failed="$failed$b_gpu "
    fi
fi

#engine_floor224_672_pal_b1(gpu)
b=engine_floor224_672_pal_b1
b_gpu=engine_floor224_672_pal_b1_gpu
echo "generating engine for $b_gpu"

sudo touch /usr/local/bin/data/pal/$b_gpu".trt"
sudo chown -R $SUDO_USER:$SUDO_USER  /usr/local/bin/data/pal/$b_gpu".trt"

trtexec --onnx=/generate/$b".onnx" --int8 --fp16 --calib=/generate/$b".cache" --saveEngine=/usr/local/bin/data/pal/$b_gpu".trt" --workspace=$1

if [ $? -eq 0 ]; then 
    rm /generate/$b".onnx"
    echo "$b_gpu engine created"
    success="$success$b_gpu "
else
    echo "$b_gpu engine creation failed"
    $failed="$failed$b_gpu "
fi

#engine_depth128_384_pal
b=engine_depth128_384_pal
echo "generating engine for $b"

sudo touch /usr/local/bin/data/pal/$b".trt"
sudo chown -R $SUDO_USER:$SUDO_USER  /usr/local/bin/data/pal/$b".trt"

trtexec --onnx=/generate/$b".onnx" --fp16 --saveEngine=/usr/local/bin/data/pal/$b".trt" --workspace=$1

if [ $? -eq 0 ]; then 
    rm /generate/$b".onnx"
    echo "$b engine created"
    success="$success$b "
else
    echo "$b engine creation failed"
    $failed="$failed$b "
fi

#engine_tracking608_1088
b=engine_tracking608_1088
echo "generating engine for $b"

sudo touch /usr/local/bin/data/pal/$b".trt"
sudo chown -R $SUDO_USER:$SUDO_USER  /usr/local/bin/data/pal/$b".trt"

trtexec --onnx=/generate/$b".onnx" --fp16 --saveEngine=/usr/local/bin/data/pal/$b".trt" --workspace=$1

if [ $? -eq 0 ]; then 
    rm /generate/$b".onnx"
    echo "$b engine created"
    success="$success$b "
else
    echo "$b engine creation failed"
    $failed="$failed$b "
fi

#engine_tracking640_640
b=engine_tracking640_640
echo "generating engine for $b"

sudo touch /usr/local/bin/data/pal/$b".trt"
sudo chown -R $SUDO_USER:$SUDO_USER  /usr/local/bin/data/pal/$b".trt"

trtexec --onnx=/generate/$b".onnx" --fp16 --saveEngine=/usr/local/bin/data/pal/$b".trt" --workspace=$1

if [ $? -eq 0 ]; then 
    rm /generate/$b".onnx"
    echo "$b engine created"
    success="$success$b "
else
    echo "$b engine creation failed"
    $failed="$failed$b "
fi

#engine_tracking1280_1280
b=engine_tracking1280_1280
echo "generating engine for $b"

sudo touch /usr/local/bin/data/pal/$b".trt"
sudo chown -R $SUDO_USER:$SUDO_USER  /usr/local/bin/data/pal/$b".trt"

trtexec --onnx=/generate/$b".onnx" --fp16 --saveEngine=/usr/local/bin/data/pal/$b".trt" --workspace=$1

if [ $? -eq 0 ]; then 
    rm /generate/$b".onnx"
    echo "$b engine created"
    success="$success$b "
else
    echo "$b engine creation failed"
    $failed="$failed$b "
fi


#engine_segmenter512_512
b=engine_segmenter512_512
b_onnx=$b
echo "generating engine for $b"

if [ $LOW_RAM_SYSTEM -eq 1 ]; then
    b_onnx=engine_segmenter512_512_lite
    MAX_SHAPE=INPUTS:1x3x512x512
else
    MAX_SHAPE=INPUTS:2x3x512x512
fi

sudo touch /usr/local/bin/data/pal/$b".trt"
sudo chown -R $SUDO_USER:$SUDO_USER  /usr/local/bin/data/pal/$b".trt"

#workspace required for segmenter is more i. e. min 400
trtexec --onnx=/generate/$b_onnx".onnx" --fp16 --saveEngine=/usr/local/bin/data/pal/$b".trt"  --minShapes=INPUTS:1x3x512x512 --optShapes=INPUTS:1x3x512x512 --maxShapes=$MAX_SHAPE --shapes=INPUTS:1x3x512x512 --workspace=400 --tacticSources=-cublasLt

if [ $? -eq 0 ]; then 
    rm /generate/$b".onnx"
    rm /generate/engine_segmenter512_512_lite.onnx
    echo "$b engine created"
    success="$success$b "
else
    echo "$b engine creation failed"
    $failed="$failed$b "
fi

#engine_depth128_480_mini
b=engine_depth128_480_mini
echo "generating engine for $b"

sudo touch /usr/local/bin/data/mini/$b".trt"
sudo chown -R $SUDO_USER:$SUDO_USER  /usr/local/bin/data/mini/$b".trt"

trtexec --onnx=/generate/$b".onnx" --fp16 --saveEngine=/usr/local/bin/data/mini/$b".trt" --workspace=$1

if [ $? -eq 0 ]; then 
    rm /generate/$b".onnx"
    echo "$b engine created"
    success="$success$b "
else
    echo "$b engine creation failed"
    $failed="$failed$b "
fi

#engine_depth384_1440_mini
b=engine_depth384_1440_mini
echo "generating engine for $b"

sudo touch /usr/local/bin/data/mini/$b".trt"
sudo chown -R $SUDO_USER:$SUDO_USER  /usr/local/bin/data/mini/$b".trt"

if [ $LOW_RAM_SYSTEM -eq 1 ]; then
    MAX_SHAPE=INPUTS:1x3x384x1440
else
    MAX_SHAPE=INPUTS:2x3x384x1440
fi

trtexec --onnx=/generate/$b".onnx" --int8 --fp16 --calib=/generate/$b".cache" --saveEngine=/usr/local/bin/data/mini/$b".trt" --workspace=$1 --minShapes=INPUTS:1x3x384x1440 --optShapes=INPUTS:1x3x384x1440 --maxShapes=$MAX_SHAPE --shapes=INPUTS:1x3x384x1440

if [ $? -eq 0 ]; then 
    rm /generate/$b".onnx"
    echo "$b engine created"
    success="$success$b "
else
    echo "$b engine creation failed"
    $failed="$failed$b "
fi

#engine_floor224_832_mini_b2(gpu)
b=engine_floor224_832_mini_b2
b_gpu=engine_floor224_832_mini_b2_gpu

if [ $LOW_RAM_SYSTEM -eq 1 ]; then
    rm /generate/$b".onnx"
else
    echo "generating engine for $b_gpu"

    sudo touch /usr/local/bin/data/mini/$b_gpu".trt"
    sudo chown -R $SUDO_USER:$SUDO_USER  /usr/local/bin/data/mini/$b_gpu".trt"

    trtexec --onnx=/generate/$b".onnx" --int8 --fp16 --calib=/generate/$b".cache" --saveEngine=/usr/local/bin/data/mini/$b_gpu".trt" --workspace=$1

    if [ $? -eq 0 ]; then 
        rm /generate/$b".onnx"
        echo "$b_gpu engine created"
        success="$success$b_gpu "
    else
        echo "$b_gpu engine creation failed"
        $failed="$failed$b_gpu "
    fi
fi

#engine_floor224_832_mini_b1(gpu)
b=engine_floor224_832_mini_b1
b_gpu=engine_floor224_832_mini_b1_gpu
echo "generating engine for $b_gpu"

sudo touch /usr/local/bin/data/mini/$b_gpu".trt"
sudo chown -R $SUDO_USER:$SUDO_USER  /usr/local/bin/data/mini/$b_gpu".trt"

trtexec --onnx=/generate/$b".onnx" --int8 --fp16 --calib=/generate/$b".cache" --saveEngine=/usr/local/bin/data/mini/$b_gpu".trt" --workspace=$1

if [ $? -eq 0 ]; then 
    rm /generate/$b".onnx"
    echo "$b_gpu engine created"
    success="$success$b_gpu "
else
    echo "$b_gpu engine creation failed"
    $failed="$failed$b_gpu "
fi

sudo chown -R dreamvu:dreamvu /usr/local/bin/data/pal/*.trt 

echo "the following engines were built successfully: $success"

