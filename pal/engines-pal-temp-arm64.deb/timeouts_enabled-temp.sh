#!/bin/sh
sudo echo 'N' > /sys/kernel/debug/gpu.0/timeouts_enabled

