if ! command -v trtexec &> /dev/null
then
    FILE=/usr/src/tensorrt/bin/trtexec
    if test -f "$FILE"; then
        export PATH=$PATH:/usr/src/tensorrt/bin
    else
        echo "Requirements not complete. Installing..."
        FOLDER=/usr/src/tensorrt/samples/trtexec/
        if [ -d "$FOLDER" ]; then
            sudo chown -R $USER: /usr/src/tensorrt/
            cd /usr/src/tensorrt/samples/trtexec/
            make
            cd -
            if test -f "$FILE"; then
                export PATH=$PATH:/usr/src/tensorrt/bin
            else
                echo "Can't locate trtexec. run: 'sudo find / -name trtexec' and add it to the PATH"
                exit
            fi
        else
            echo "Can't locate trtexec folder. run: 'sudo find / -name tensorrt' and find the folder with trtexec. Go in that folder and run 'make'"
            exit
        fi
    fi
fi


success=""
failed=""

b=engine_depth384_1120_pal
echo "generating engine for $b"


if [ -e /sys/firmware/devicetree/base/model ]; then
    JETSON_TYPE=$(tr -d '\0' < /sys/firmware/devicetree/base/model)
fi

touch /usr/local/bin/data/pal/$b".trt"
chown -R $SUDO_USER:$SUDO_USER  /usr/local/bin/data/pal/$b".trt"

if [[ $JETSON_TYPE =~ "Jetson-AGX"  || $JETSON_TYPE =~ "Xavier NX" ]]; then
	trtexec --onnx=/generate/$b".onnx" --int8 --fp16 --calib=/calib_depth.cache --useDLACore=1 --allowGPUFallback --saveEngine=/usr/local/bin/data/pal/$b".trt" --workspace=$1 --minShapes=INPUTS:1x3x384x1120 --optShapes=INPUTS:1x3x384x1120 --maxShapes=INPUTS:2x3x384x1120 --shapes=INPUTS:1x3x384x1120
else
	trtexec --onnx=/generate/$b".onnx" --int8 --fp16 --calib=/calib_depth.cache --saveEngine=/usr/local/bin/data/pal/$b".trt" --workspace=$1 --minShapes=INPUTS:1x3x384x1120 --optShapes=INPUTS:1x3x384x1120 --maxShapes=INPUTS:2x3x384x1120 --shapes=INPUTS:1x3x384x1120
fi

if [ $? -eq 0 ]; then 
    rm /generate/$b".onnx"
    echo "$b engine created"
    success="$success$b "
else
    echo "$b engine creation failed"
    $failed="$failed$b "
fi

b=engine_floor224_1600_pal_b1
echo "generating engine for $b"
touch /usr/local/bin/data/pal/$b".trt"
chown -R $SUDO_USER:$SUDO_USER  /usr/local/bin/data/pal/$b".trt"
trtexec --onnx=/generate/$b".onnx" --int8 --fp16 --calib=/calib_b1.cache --saveEngine=/usr/local/bin/data/pal/$b".trt" --workspace=$1

if [ $? -eq 0 ]; then  
    rm /generate/$b".onnx"
    echo "$b engine created"
    success="$success$b "
else
    echo "$b engine creation failed"
    $failed="$failed$b "
fi

b=engine_floor224_1600_pal_b2
echo "generating engine for $b"
touch /usr/local/bin/data/pal/$b".trt"
chown -R $SUDO_USER:$SUDO_USER  /usr/local/bin/data/pal/$b".trt"
trtexec --onnx=/generate/$b".onnx" --int8 --fp16 --calib=/calib_b2.cache --saveEngine=/usr/local/bin/data/pal/$b".trt" --workspace=$1
    
if [ $? -eq 0 ]; then  
    rm /generate/$b".onnx"
    echo "$b engine created"
    success="$success$b "
else
    echo "$b engine creation failed"
    $failed="$failed$b "
fi

sudo chown -R dreamvu:dreamvu /usr/local/bin/data/pal/*.trt 

echo "the following engines were built successfully: $success"

