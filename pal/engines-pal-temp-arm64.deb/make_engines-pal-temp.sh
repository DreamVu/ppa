if ! command -v trtexec &> /dev/null
then
    FILE=/usr/src/tensorrt/bin/trtexec
    if test -f "$FILE"; then
        export PATH=$PATH:/usr/src/tensorrt/bin
    else
        echo "Requirements not complete. Installing..."
        FOLDER=/usr/src/tensorrt/samples/trtexec/
        if [ -d "$FOLDER" ]; then
            sudo chown -R $USER: /usr/src/tensorrt/
            cd /usr/src/tensorrt/samples/trtexec/
            make
            cd -
            if test -f "$FILE"; then
                export PATH=$PATH:/usr/src/tensorrt/bin
            else
                echo "Can't locate trtexec. run: 'sudo find / -name trtexec' and add it to the PATH"
                exit
            fi
        else
            echo "Can't locate trtexec folder. run: 'sudo find / -name tensorrt' and find the folder with trtexec. Go in that folder and run 'make'"
            exit
        fi
    fi
fi

if [ -e /sys/firmware/devicetree/base/model ]; then
    JETSON_TYPE=$(tr -d '\0' < /sys/firmware/devicetree/base/model)
fi

success=""
failed=""
DLA=""

if [[ $JETSON_TYPE =~ "Jetson-AGX"  || $JETSON_TYPE =~ "Xavier NX" ]]; then
DLA="--useDLACore=0 --allowGPUFallback"
fi

MIDAS128_CACHE_PAL="./engine_depth128_384_pal.cache"
MIDAS128_CACHE_MINI="./engine_depth128_480_mini.cache"

jp_version=$(sudo apt-cache show nvidia-jetpack | grep Version)
if [[ $jp_version =~ "Version: 4.6-" ]]; then 
    MIDAS128_CACHE_PAL="./engine_depth128_384_pal_jp46.cache"  
    MIDAS128_CACHE_MINI="./engine_depth128_480_mini_jp46.cache"  
fi

#engine_depth384_1120_pal
b=engine_depth384_1120_pal
echo "generating engine for $b"

sudo touch /usr/local/bin/data/pal/$b".trt"
sudo chown -R $SUDO_USER:$SUDO_USER  /usr/local/bin/data/pal/$b".trt"

trtexec --onnx=/generate/$b".onnx" --int8 --fp16 --calib=/generate/$b".cache" $DLA --saveEngine=/usr/local/bin/data/pal/$b".trt" --workspace=$1 --minShapes=INPUTS:1x3x384x1120 --optShapes=INPUTS:1x3x384x1120 --maxShapes=INPUTS:2x3x384x1120 --shapes=INPUTS:1x3x384x1120

if [ $? -eq 0 ]; then 
    rm /generate/$b".onnx"
    echo "$b engine created"
    success="$success$b "
else
    echo "$b engine creation failed"
    $failed="$failed$b "
fi

#engine_floor224_672_pal_b2(gpu and dla)
b=engine_floor224_672_pal_b2
b_dla=engine_floor224_672_pal_b2_dla
b_gpu=engine_floor224_672_pal_b2_gpu
echo "generating engine for $b_gpu"

sudo touch /usr/local/bin/data/pal/$b_gpu".trt"
sudo chown -R $SUDO_USER:$SUDO_USER  /usr/local/bin/data/pal/$b_gpu".trt"

trtexec --onnx=/generate/$b".onnx" --int8 --fp16 --calib=/generate/$b".cache" --saveEngine=/usr/local/bin/data/pal/$b_gpu".trt" --workspace=$1

if [ $? -eq 0 ]; then 
    echo "$b_gpu engine created"
    success="$success$b_gpu "
else
    echo "$b_gpu engine creation failed"
    $failed="$failed$b_gpu "
fi


if [[ $JETSON_TYPE =~ "Jetson-AGX"  || $JETSON_TYPE =~ "Xavier NX" ]]; then
	trtexec --onnx=/generate/$b".onnx" --int8 --fp16 --calib=/generate/$b".cache" $DLA --saveEngine=/usr/local/bin/data/pal/$b_dla".trt" --workspace=$1

	echo "generating engine for $b_dla"

	sudo touch /usr/local/bin/data/pal/$b_dla".trt"
	sudo chown -R $SUDO_USER:$SUDO_USER  /usr/local/bin/data/pal/$b_dla".trt"
	
	
	if [ $? -eq 0 ]; then 
		echo "$b_dla engine created"
		success="$success$b_dla "
	else
		echo "$b_dla engine creation failed"
		$failed="$failed$b_dla "
	fi
fi

rm /generate/$b".onnx"

#engine_floor224_672_pal_b1(gpu and dla)
b=engine_floor224_672_pal_b1
b_dla=engine_floor224_672_pal_b1_dla
b_gpu=engine_floor224_672_pal_b1_gpu
echo "generating engine for $b_gpu"

sudo touch /usr/local/bin/data/pal/$b_gpu".trt"
sudo chown -R $SUDO_USER:$SUDO_USER  /usr/local/bin/data/pal/$b_gpu".trt"

trtexec --onnx=/generate/$b".onnx" --int8 --fp16 --calib=/generate/$b".cache" --saveEngine=/usr/local/bin/data/pal/$b_gpu".trt" --workspace=$1

if [ $? -eq 0 ]; then 
    echo "$b_gpu engine created"
    success="$success$b_gpu "
else
    echo "$b_gpu engine creation failed"
    $failed="$failed$b_gpu "
fi


if [[ $JETSON_TYPE =~ "Jetson-AGX"  || $JETSON_TYPE =~ "Xavier NX" ]]; then
	trtexec --onnx=/generate/$b".onnx" --int8 --fp16 --calib=/generate/$b".cache" $DLA --saveEngine=/usr/local/bin/data/pal/$b_dla".trt" --workspace=$1

	echo "generating engine for $b_dla"

	sudo touch /usr/local/bin/data/pal/$b_dla".trt"
	sudo chown -R $SUDO_USER:$SUDO_USER  /usr/local/bin/data/pal/$b_dla".trt"
	
	
	if [ $? -eq 0 ]; then 
		echo "$b_dla engine created"
		success="$success$b_dla "
	else
		echo "$b_dla engine creation failed"
		$failed="$failed$b_dla "
	fi
fi

rm /generate/$b".onnx"

#engine_depth128_384_pal
b=engine_depth128_384_pal
echo "generating engine for $b"

sudo touch /usr/local/bin/data/pal/$b".trt"
sudo chown -R $SUDO_USER:$SUDO_USER  /usr/local/bin/data/pal/$b".trt"

trtexec --onnx=/generate/$b".onnx" --int8 --fp16 --calib=/generate/$MIDAS128_CACHE_PAL $DLA --saveEngine=/usr/local/bin/data/pal/$b".trt" --workspace=$1

if [ $? -eq 0 ]; then 
    rm /generate/$b".onnx"
    echo "$b engine created"
    success="$success$b "
else
    echo "$b engine creation failed"
    $failed="$failed$b "
fi

#engine_tracking608_1088
b=engine_tracking608_1088
echo "generating engine for $b"

sudo touch /usr/local/bin/data/pal/$b".trt"
sudo chown -R $SUDO_USER:$SUDO_USER  /usr/local/bin/data/pal/$b".trt"

trtexec --onnx=/generate/$b".onnx" --fp16 --saveEngine=/usr/local/bin/data/pal/$b".trt" --workspace=$1

if [ $? -eq 0 ]; then 
    rm /generate/$b".onnx"
    echo "$b engine created"
    success="$success$b "
else
    echo "$b engine creation failed"
    $failed="$failed$b "
fi

#engine_tracking640_640
b=engine_tracking640_640
echo "generating engine for $b"

sudo touch /usr/local/bin/data/pal/$b".trt"
sudo chown -R $SUDO_USER:$SUDO_USER  /usr/local/bin/data/pal/$b".trt"

trtexec --onnx=/generate/$b".onnx" --fp16 --saveEngine=/usr/local/bin/data/pal/$b".trt" --workspace=$1

if [ $? -eq 0 ]; then 
    rm /generate/$b".onnx"
    echo "$b engine created"
    success="$success$b "
else
    echo "$b engine creation failed"
    $failed="$failed$b "
fi

#engine_tracking1280_1280
b=engine_tracking1280_1280
echo "generating engine for $b"

sudo touch /usr/local/bin/data/pal/$b".trt"
sudo chown -R $SUDO_USER:$SUDO_USER  /usr/local/bin/data/pal/$b".trt"

trtexec --onnx=/generate/$b".onnx" --fp16 --saveEngine=/usr/local/bin/data/pal/$b".trt" --workspace=$1

if [ $? -eq 0 ]; then 
    rm /generate/$b".onnx"
    echo "$b engine created"
    success="$success$b "
else
    echo "$b engine creation failed"
    $failed="$failed$b "
fi

#engine_depth128_480_mini
b=engine_depth128_480_mini
echo "generating engine for $b"

sudo touch /usr/local/bin/data/mini/$b".trt"
sudo chown -R $SUDO_USER:$SUDO_USER  /usr/local/bin/data/mini/$b".trt"

trtexec --onnx=/generate/$b".onnx" --int8 --fp16 --calib=/generate/$MIDAS128_CACHE_MINI $DLA --saveEngine=/usr/local/bin/data/mini/$b".trt" --workspace=$1

if [ $? -eq 0 ]; then 
    rm /generate/$b".onnx"
    echo "$b engine created"
    success="$success$b "
else
    echo "$b engine creation failed"
    $failed="$failed$b "
fi

#engine_depth384_1440_mini
b=engine_depth384_1440_mini
echo "generating engine for $b"

sudo touch /usr/local/bin/data/mini/$b".trt"
sudo chown -R $SUDO_USER:$SUDO_USER  /usr/local/bin/data/mini/$b".trt"

trtexec --onnx=/generate/$b".onnx" --int8 --fp16 --calib=/generate/$b".cache" $DLA --saveEngine=/usr/local/bin/data/mini/$b".trt" --workspace=$1 --minShapes=INPUTS:1x3x384x1440 --optShapes=INPUTS:1x3x384x1440 --maxShapes=INPUTS:2x3x384x1440 --shapes=INPUTS:1x3x384x1440

if [ $? -eq 0 ]; then 
    rm /generate/$b".onnx"
    echo "$b engine created"
    success="$success$b "
else
    echo "$b engine creation failed"
    $failed="$failed$b "
fi

#engine_floor224_832_mini_b2(gpu and dla)
b=engine_floor224_832_mini_b2
b_dla=engine_floor224_832_mini_b2_dla
b_gpu=engine_floor224_832_mini_b2_gpu
echo "generating engine for $b_gpu"

sudo touch /usr/local/bin/data/mini/$b_gpu".trt"
sudo chown -R $SUDO_USER:$SUDO_USER  /usr/local/bin/data/mini/$b_gpu".trt"

trtexec --onnx=/generate/$b".onnx" --int8 --fp16 --calib=/generate/$b".cache" --saveEngine=/usr/local/bin/data/mini/$b_gpu".trt" --workspace=$1

if [ $? -eq 0 ]; then 
    echo "$b_gpu engine created"
    success="$success$b_gpu "
else
    echo "$b_gpu engine creation failed"
    $failed="$failed$b_gpu "
fi


if [[ $JETSON_TYPE =~ "Jetson-AGX"  || $JETSON_TYPE =~ "Xavier NX" ]]; then
	trtexec --onnx=/generate/$b".onnx" --int8 --fp16 --calib=/generate/$b".cache" $DLA --saveEngine=/usr/local/bin/data/mini/$b_dla".trt" --workspace=$1

	echo "generating engine for $b_dla"

	sudo touch /usr/local/bin/data/mini/$b_dla".trt"
	sudo chown -R $SUDO_USER:$SUDO_USER  /usr/local/bin/data/mini/$b_dla".trt"

	if [ $? -eq 0 ]; then 
		echo "$b_dla engine created"
		success="$success$b_dla "
	else
		echo "$b_dla engine creation failed"
		$failed="$failed$b_dla "
	fi
fi

rm /generate/$b".onnx"


#engine_floor224_832_mini_b1(gpu and dla)
b=engine_floor224_832_mini_b1
b_dla=engine_floor224_832_mini_b1_dla
b_gpu=engine_floor224_832_mini_b1_gpu
echo "generating engine for $b_gpu"

sudo touch /usr/local/bin/data/mini/$b_gpu".trt"
sudo chown -R $SUDO_USER:$SUDO_USER  /usr/local/bin/data/mini/$b_gpu".trt"

trtexec --onnx=/generate/$b".onnx" --int8 --fp16 --calib=/generate/$b".cache" --saveEngine=/usr/local/bin/data/mini/$b_gpu".trt" --workspace=$1

if [ $? -eq 0 ]; then 
    echo "$b_gpu engine created"
    success="$success$b_gpu "
else
    echo "$b_gpu engine creation failed"
    $failed="$failed$b_gpu "
fi


if [[ $JETSON_TYPE =~ "Jetson-AGX"  || $JETSON_TYPE =~ "Xavier NX" ]]; then
	trtexec --onnx=/generate/$b".onnx" --int8 --fp16 --calib=/generate/$b".cache" $DLA --saveEngine=/usr/local/bin/data/mini/$b_dla".trt" --workspace=$1

	echo "generating engine for $b_dla"

	sudo touch /usr/local/bin/data/mini/$b_dla".trt"
	sudo chown -R $SUDO_USER:$SUDO_USER  /usr/local/bin/data/mini/$b_dla".trt"
	
	if [ $? -eq 0 ]; then 
		echo "$b_dla engine created"
		success="$success$b_dla "
	else
		echo "$b_dla engine creation failed"
		$failed="$failed$b_dla "
	fi
fi

rm /generate/$b".onnx"

sudo chown -R dreamvu:dreamvu /usr/local/bin/data/pal/*.trt 

echo "the following engines were built successfully: $success"

