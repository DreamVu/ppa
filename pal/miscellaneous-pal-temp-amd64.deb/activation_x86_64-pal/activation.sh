#!/bin/bash

version=$(lsb_release -sc)

if [[ "$version" == "focal" ]]; then
    #ubuntu 20.04
    if [ -e ./Ubuntu_20.04/run ]
    then
        cp ./Ubuntu_20.04/run ./
        rm -rf ./Ubuntu_20.04/ 
    fi
fi

./run


