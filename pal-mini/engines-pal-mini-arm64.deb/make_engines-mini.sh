if ! command -v trtexec &> /dev/null
then
    FILE=/usr/src/tensorrt/bin/trtexec
    if test -f "$FILE"; then
        export PATH=$PATH:/usr/src/tensorrt/bin
    else
        echo "Requirements not complete. Installing..."
        FOLDER=/usr/src/tensorrt/samples/trtexec/
        if [ -d "$FOLDER" ]; then
            sudo chown -R $USER: /usr/src/tensorrt/
            cd /usr/src/tensorrt/samples/trtexec/
            make
            cd -
            if test -f "$FILE"; then
                export PATH=$PATH:/usr/src/tensorrt/bin
            else
                echo "Can't locate trtexec. run: 'sudo find / -name trtexec' and add it to the PATH"
                exit
            fi
        else
            echo "Can't locate trtexec folder. run: 'sudo find / -name tensorrt' and find the folder with trtexec. Go in that folder and run 'make'"
            exit
        fi
    fi
fi

a=1

success=""
failed=""
while [ $a -lt 6 ]
do
    echo "generating engine for depth$a.bin"
    
    b=engine_depth_mini$a.trt
    c=depth$a.bin

    trtexec --onnx=/generate/$c --fp16 --batch=1 --saveEngine=/usr/local/bin/data/mini/$b --workspace=$1

    if [ $? -eq 0 ]; then 
        rm /generate/$c
        echo "$b engine created"
        success="$success$b "
    else
        echo "$b engine creation failed"
        $failed="$failed$b "
    fi
    a=`expr $a + 1`
done

a=1

while [ $a -lt 6 ]
do
    echo "generating engine for floor$a.bin"

    b=engine_floor_mini$a"_b1.trt"
    c=floor$a"_b1.bin"

    trtexec --onnx=/generate/$c --fp16 --batch=1 --saveEngine=/usr/local/bin/data/mini/$b --workspace=$1

    if [ $? -eq 0 ]; then 
        rm /generate/$c
        echo "$b engine created"
        success="$success$b "
    else
        echo "$b engine creation failed"
        $failed="$failed$b "
    fi
    a=`expr $a + 1`
done

a=1

while [ $a -lt 6 ]
do
    echo "generating engine for floor$a.bin"

    b=engine_floor_mini$a"_b2.trt"
    c=floor$a"_b2.bin"

    trtexec --onnx=/generate/$c --fp16 --batch=1 --saveEngine=/usr/local/bin/data/mini/$b --workspace=$1

    if [ $? -eq 0 ]; then  
        rm /generate/$c
        echo "$b engine created"
        success="$success$b "
    else
        echo "$b engine creation failed"
        $failed="$failed$b "
    fi
    a=`expr $a + 1`
done

sudo chown -R dreamvu:dreamvu /usr/local/bin/data/mini/*.trt 

echo "the following engines were built successfully: $success"

